..
   ****************************************************************************
    pgRouting Manual
    Copyright(c) pgRouting Contributors

    This documentation is licensed under a Creative Commons Attribution-Share
    Alike 3.0 License: http://creativecommons.org/licenses/by-sa/3.0/
   ****************************************************************************

.. index::
   single: Traversal Family ; pgr_breadthFirstSearch - Experimental
   single: Breadth First Search Category ; pgr_breadthFirstSearch - Experimental
   single: breadthFirstSearch - Experimental

|

``pgr_breadthFirstSearch`` - Experimental
===============================================================================

``pgr_breadthFirstSearch`` — Returns the traversal order(s) using Breadth First
Search algorithm.

.. include:: experimental.rst
   :start-after: warning-begin
   :end-before: end-warning

.. rubric:: Availability

* Version 3.0.0

  * New experimental function.

Description
-------------------------------------------------------------------------------

Provides the Breadth First Search traversal order from a root vertex to a
particular depth.

**The main Characteristics are:**

* The implementation will work on any type of graph.
* Provides the Breadth First Search traversal order from a source node to a
  target depth level.
* Running time: :math:`O(E + V)`

|Boost| Boost Graph Inside

Signatures
-------------------------------------------------------------------------------

.. rubric:: Summary

.. admonition:: \ \
   :class: signatures

   | pgr_breadthFirstSearch(`Edges SQL`_, **root vid**, [**options**])
   | pgr_breadthFirstSearch(`Edges SQL`_, **root vids**, [**options**])
   | **options:** [max_depth, directed]``

   | Returns set of |result-bfs|

.. index::
    single: breadthFirstSearch - Experimental ; Single vertex - Experimental on v3.0

Single vertex
...............................................................................

.. admonition:: \ \
   :class: signatures

   | pgr_breadthFirstSearch(`Edges SQL`_, **root vid**, [**options**])
   | **options:** [max_depth, directed]``

   | Returns set of |result-bfs|

:Example: From root vertex :math:`6` on a **directed** graph with edges in
          ascending order of ``id``

.. literalinclude:: breadthFirstSearch.queries
   :start-after: -- q1
   :end-before: -- q2

.. index::
    single: breadthFirstSearch - Experimental ; Multiple vertices - Experimental on v3.0

Multiple vertices
...............................................................................

.. admonition:: \ \
   :class: signatures

   | pgr_breadthFirstSearch(`Edges SQL`_, **root vids**, [**options**])
   | **options:** [max_depth, directed]``

   | Returns set of |result-bfs|

:Example: From root vertices :math:`\{12, 6\}` on an **undirected** graph with
          **depth** :math:`<= 2` and edges in ascending order of ``id``

.. literalinclude:: breadthFirstSearch.queries
   :start-after: -- q2
   :end-before: -- q3

Parameters
-------------------------------------------------------------------------------

.. include:: BFS-category.rst
   :start-after: mst-bfs-dfs-params_start
   :end-before: mst-bfs-dfs-params_end

Optional parameters
...............................................................................

.. include:: dijkstra-family.rst
    :start-after: dijkstra_optionals_start
    :end-before: dijkstra_optionals_end

DFS optional parameters
...............................................................................

.. include:: BFS-category.rst
   :start-after: max-depth-optional-start
   :end-before: max-depth-optional-end

Inner Queries
-------------------------------------------------------------------------------

Edges SQL
...............................................................................

.. include:: pgRouting-concepts.rst
   :start-after: basic_edges_sql_start
   :end-before: basic_edges_sql_end

Result columns
-------------------------------------------------------------------------------

.. include:: BFS-category.rst
   :start-after: mst-bfs-dfs-dd-result-columns-start
   :end-before: mst-bfs-dfs-dd-result-columns-end

Additional Examples
-------------------------------------------------------------------------------

:Example: Same as `Single vertex`_ with edges in ascending order of ``id``.

.. literalinclude:: breadthFirstSearch.queries
   :start-after: -- q1
   :end-before: -- q2

:Example: Same as `Single vertex`_ with edges in descending order of ``id``.

.. literalinclude:: breadthFirstSearch.queries
   :start-after: -- q3
   :end-before: -- q4

The resulting traversal is different.

The left image shows the result with ascending order of ids and the right image
shows with descending order of the edge identifiers.

|ascending| |descending|

.. |ascending| image:: images/bfs-ascending.png
   :scale: 25%

.. |descending| image:: images/bfs-descending.png
   :scale: 25%

See Also
-------------------------------------------------------------------------------

* :doc:`BFS-category`
* :doc:`sampledata`
* `Boost: Breadth First Search
  <https://www.boost.org/libs/graph/doc/breadth_first_search.html>`__
* `Wikipedia: Breadth First Search algorithm
  <https://en.wikipedia.org/wiki/Breadth-first_search>`__

.. rubric:: Indices and tables

* :ref:`genindex`
* :ref:`search`
