..
   ****************************************************************************
    pgRouting Manual
    Copyright(c) pgRouting Contributors

    This documentation is licensed under a Creative Commons Attribution-Share
    Alike 3.0 License: https://creativecommons.org/licenses/by-sa/3.0/
   ****************************************************************************


*******************************************************************************
Function Families
*******************************************************************************

..
    from-here


:doc:`allpairs-family`

.. include:: allpairs-family.rst
   :start-after: official-start
   :end-before: official-end

:doc:`aStar-family`

.. include:: aStar-family.rst
   :start-after: official-start
   :end-before: official-end


:doc:`bdAstar-family`

.. include:: bdAstar-family.rst
   :start-after: official-start
   :end-before: official-end

:doc:`bdDijkstra-family`

.. include:: bdDijkstra-family.rst
   :start-after: official-start
   :end-before: official-end

:doc:`components-family`

.. include:: components-family.rst
   :start-after: official-start
   :end-before: official-end

:doc:`contraction-family`

.. include:: contraction-family.rst
   :start-after: official-start
   :end-before: official-end

:doc:`dijkstra-family`

.. include:: dijkstra-family.rst
   :start-after: official-start
   :end-before: official-end

:doc:`flow-family`

.. include:: flow-family.rst
   :start-after: official-start
   :end-before: official-end

:doc:`kruskal-family`

.. include:: kruskal-family.rst
      :start-after: official-start
      :end-before: official-end

:doc:`prim-family`

.. include:: prim-family.rst
      :start-after: official-start
      :end-before: official-end

:doc:`reference`

.. include:: reference.rst
   :start-after: official-start
   :end-before: official-end

:doc:`topology-functions`

.. include:: topology-functions.rst
   :start-after: official-start
   :end-before: official-end

:doc:`TSP-family`

.. include:: TSP-family.rst
   :start-after: official-start
   :end-before: official-end

:doc:`pgr_trsp` - Turn Restriction Shortest Path (TRSP)


Functions by categories
===============================================================================

:doc:`cost-category`

.. include:: cost-category.rst
   :start-after: official-start
   :end-before: official-end

:doc:`costMatrix-category`

.. include:: costMatrix-category.rst
   :start-after: official-start
   :end-before: official-end


:doc:`drivingDistance-category`

.. include:: drivingDistance-category.rst
   :start-after: official-start
   :end-before: official-end

:doc:`KSP-category`

.. include:: KSP-category.rst
   :start-after: official-start
   :end-before: official-end

:doc:`spanningTree-family`

.. include:: spanningTree-family.rst
   :start-after: official-start
   :end-before: official-end

:doc:`BFS-category`

.. include:: BFS-category.rst
   :start-after: official-start
   :end-before: official-end

:doc:`DFS-category`

.. include:: DFS-category.rst
   :start-after: official-start
   :end-before: official-end

.. to-here

.. toctree::
    :hidden:

    allpairs-family
    aStar-family
    bdAstar-family
    bdDijkstra-family
    components-family
    contraction-family
    dijkstra-family
    flow-family
    kruskal-family
    prim-family
    reference
    topology-functions
    TSP-family

.. toctree::
    :hidden:

    BFS-category
    cost-category
    costMatrix-category
    DFS-category
    drivingDistance-category
    KSP-category
    spanningTree-family
    via-category
    VRP-category
    withPoints-category

See Also
-------------------------------------------------------------------------------

.. rubric:: Indices and tables

* :ref:`genindex`
* :ref:`search`
